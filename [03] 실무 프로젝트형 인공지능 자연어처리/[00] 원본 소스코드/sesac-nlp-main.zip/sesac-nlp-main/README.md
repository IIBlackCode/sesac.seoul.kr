# sesac-nlp
실무형 인공지능 자연어처리 
